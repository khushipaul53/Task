package com.example.apptunixtask;

public class AplhaModel {
    private  int image;
    private String alphaName;

    public AplhaModel(int image, String alphaName){
        this.image = image;
        this.alphaName = alphaName;
    }
    public int getHeroImage() {
        return image;
    }
    public String getMovieName() {
        return alphaName;
    }
}
