package com.example.apptunixtask;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class InstructionsActivity extends AppCompatActivity {
TextView tvInstructions;
Button btClick;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructions);
        tvInstructions=findViewById(R.id.tvInstructions);
        btClick=findViewById(R.id.btClick);
        btClick.setText(R.string.next);

        tvInstructions.setText(R.string.instructions);


        btClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent movetoNextActivity=new Intent(InstructionsActivity.this,MainActivity.class);
                startActivity(movetoNextActivity);
                finish();

            }
        });


    }
}