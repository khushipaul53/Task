package com.example.apptunixtask;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class EnglishAlphaAdapter extends RecyclerView.Adapter<EnglishAlphaAdapter.MyViewHolder> {

    public ArrayList<AplhaModel> alphaModelArrayList;
    Context mContext;
    private int selectedPosition = -1;
    private boolean flag = true;


    public EnglishAlphaAdapter(ArrayList<AplhaModel> arrayList, Context context) {
        this.alphaModelArrayList = arrayList;
        this.mContext = context;
    }

    @NonNull
    @Override
    public EnglishAlphaAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.english_alpha_items, parent, false);


        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EnglishAlphaAdapter.MyViewHolder holder, int position) {
        AplhaModel currentItem = alphaModelArrayList.get(position);
        holder.AlphaImage.setImageResource(currentItem.getHeroImage());
        holder.AlphaName.setText(currentItem.getMovieName());

        if (selectedPosition == position) {
            holder.itemView.setBackgroundColor(Color.parseColor("#000000"));
            holder.cdAlpha.setBackgroundColor(Color.parseColor("#000000"));
            holder.AlphaName.setTextColor(Color.parseColor("#FFFFFF"));
        } else {
            holder.itemView.setBackgroundColor(Color.parseColor("#ffffff"));
            holder.cdAlpha.setBackgroundColor(Color.parseColor("#ffffff"));
            holder.AlphaName.setTextColor(Color.parseColor("#000000"));

        }


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                selectedPosition = position;
                notifyDataSetChanged();

            }
        });

    holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    for(int i=0;i<4;i++) {
                        holder.cdAlpha.setSelected(!holder.cdAlpha.isSelected());
                        holder.cdAlpha.setBackgroundColor(holder.cdAlpha.isSelected() ? Color.CYAN : Color.WHITE);
                    }
                        return false;

                }
            });


        }






    @Override
    public int getItemCount() {
        return alphaModelArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        public ImageView AlphaImage;
        public TextView AlphaName;
        public CardView cdAlpha;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            AlphaImage = itemView.findViewById(R.id.alpha_image);
            AlphaName = itemView.findViewById(R.id.alphaTitle);
            cdAlpha=itemView.findViewById(R.id.cdAlpha);




        }


        }

    }

