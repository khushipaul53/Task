package com.example.apptunixtask;

import android.animation.ValueAnimator;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.MyViewHolder> {
    private ArrayList<CategoryModel> categroyArrayList;
    public Context mcontext;
    boolean flag=true;

    public CategoryAdapter(ArrayList<CategoryModel> categroyArrayList, Context mainActivity) {
        this.categroyArrayList = categroyArrayList;
        this.mcontext = mainActivity;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.alphabet_items, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        CategoryModel currentItem = categroyArrayList.get(position);


        holder.category.setText(currentItem.Category());
        ArrayList<AplhaModel> arrayList = new ArrayList<>();
        if (categroyArrayList.get(position).Category().equals("Category1")) {
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "A"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "B"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "C"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "D"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "E"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "F"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "A"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "B"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "C"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "D"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "E"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "F"));
            holder.categoryRecyclerView.setLayoutManager(new GridLayoutManager(mcontext, 4));
            holder.category.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(flag){
                    holder.categoryRecyclerView.setVisibility(View.GONE);
                    flag=false;
                    }
                    else{
                        holder.categoryRecyclerView.setVisibility(View.VISIBLE);
                        flag=true;


                    }


                }
            });



        }

        // added in second child row
        if (categroyArrayList.get(position).Category().equals("Category2")) {
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "1"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "2"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "3"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "4"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "5"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "6"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "7"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "8"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "9"));
            RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mcontext, LinearLayoutManager.VERTICAL, false);
            holder.categoryRecyclerView.setLayoutManager(layoutManager);
            holder.categoryRecyclerView.setHasFixedSize(true);

            holder.category.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(flag){
                        holder.categoryRecyclerView.setVisibility(View.GONE);
                        flag=false;
                    }
                    else{
                        holder.categoryRecyclerView.setVisibility(View.VISIBLE);
                        flag=true;


                    }


                }
            });
        }

        // added in third child row
        if (categroyArrayList.get(position).Category().equals("Category3")) {
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "क"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "ख"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "ग"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "क"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "ख"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "ग"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "क"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "ख"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "ग"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "क"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "ख"));
            arrayList.add(new AplhaModel(R.drawable.ic_launcher_background, "ग"));
            RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mcontext, LinearLayoutManager.HORIZONTAL, false);
            holder.categoryRecyclerView.setLayoutManager(layoutManager);
            holder.categoryRecyclerView.setHasFixedSize(true);
        }
        EnglishAlphaAdapter categoryRecyclerView = new EnglishAlphaAdapter(arrayList, holder.categoryRecyclerView.getContext());
        holder.categoryRecyclerView.setAdapter(categoryRecyclerView);
        holder.category.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(flag){
                    holder.categoryRecyclerView.setVisibility(View.GONE);
                    flag=false;
                }
                else{
                    holder.categoryRecyclerView.setVisibility(View.VISIBLE);
                    flag=true;


                }


            }
        });


    }

    @Override
    public int getItemCount() {
        return categroyArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        public TextView category;
        public RecyclerView categoryRecyclerView;

        public MyViewHolder(@NonNull View itemView) {

            super(itemView);
            category = itemView.findViewById(R.id.tvCategory);
            categoryRecyclerView = itemView.findViewById(R.id.rvalpha);


        }


    }

    }

