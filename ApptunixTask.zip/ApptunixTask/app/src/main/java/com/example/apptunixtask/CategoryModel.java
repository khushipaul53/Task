package com.example.apptunixtask;

public class CategoryModel {
    private String Category;

    public CategoryModel(String Category) {
        this.Category = Category;
    }
    public String Category() {
        return Category;
}
    }
