package com.example.apptunixtask;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView parentRecyclerView;
    private RecyclerView.Adapter CategoryAdapter;
    ArrayList<CategoryModel> parentModelArrayList = new ArrayList<>();
    private RecyclerView.LayoutManager parentLayoutManager;
    private LinearLayout llMain;
    private RecyclerView.Adapter EnglishAlphaAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        llMain=findViewById(R.id.llMain);
        parentModelArrayList.add(new CategoryModel("Category1"));
        parentModelArrayList.add(new CategoryModel("Category2"));
        parentModelArrayList.add(new CategoryModel("Category3"));

        parentRecyclerView = findViewById(R.id.rvAlphabets);
        parentRecyclerView.setHasFixedSize(true);
        parentLayoutManager = new LinearLayoutManager(this);

        CategoryAdapter = new CategoryAdapter(parentModelArrayList, MainActivity.this);
        parentRecyclerView.setLayoutManager(parentLayoutManager);
        parentRecyclerView.setAdapter(CategoryAdapter);
        CategoryAdapter.notifyDataSetChanged();


    }




}